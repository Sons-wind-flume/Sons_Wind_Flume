package org.windflume.ui;

import java.awt.BorderLayout;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class GaugeBlockPanel extends JPanel {

    private final XYSeries series;
    private double x = 0;

    public GaugeBlockPanel(String title) {

        setLayout(new BorderLayout());

       series = new XYSeries(title);

        XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(series);     

        JFreeChart chart = ChartFactory.createXYLineChart(
                        title,
                        "Time",
                        "Voltage",
                        dataset
                );
                chart.removeLegend();

                add(new ChartPanel(chart), BorderLayout.CENTER);
    }

    public void addVoltage (double voltage){
            series.add(x, voltage);
            x++;

        if (series.getItemCount() > 100) {
            series.remove(0);
        }
    }
    

    public void clearGraph() {

        series.clear();
        x = 0;
    }
}